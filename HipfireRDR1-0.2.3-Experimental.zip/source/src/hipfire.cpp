#define WIN32_LEAN_AND_MEAN
#include "redhook.hpp"
#include <cmath>

// Experimental engine-task prototype. No EXE patch and no synthetic projectile.
// The node path and task argument layout were recovered from user-supplied files.
namespace {
constexpr const char* root = "default_character_Main";
constexpr const char* pose =
    "default_character_Main\\Gunplay\\Pistol\\DeadEye\\PistolHoldStand";
struct Vec3 { float x, y, z; };
static_assert(sizeof(Vec3) == 12);
int owned_actor = -1;
ULONGLONG release_at = 0;
bool enabled = true;
// This player-state flag is read by the weapon controller. Actor heading
// corrections cannot supply that state and did not fix the rendered pose.
int forced_aim_player = -1;

bool foreground() {
    DWORD pid = 0;
    GetWindowThreadProcessId(GetForegroundWindow(), &pid);
    return pid == GetCurrentProcessId();
}
bool down(int key) { return (GetAsyncKeyState(key) & 0x8000) != 0; }

void release() {
    // The flag belongs to the player controller, not the actor handle: clear it
    // even when that handle died, changed or became invalid during the shot.
    if (forced_aim_player != -1) {
        rh::native<0x1CFAF2EA, void>(forced_aim_player, 0);
        forced_aim_player = -1;
    }
    if (owned_actor == -1) return;
    const int player = rh::native<0xAD68A22E>();
    if (rh::native<0xBA6C3E92>(owned_actor) && rh::native<0x2F232639>(owned_actor)
            && owned_actor == rh::native<0xE8CFDD53>(player)
            && rh::native<0x9613C2D0>(player) && !rh::native<0xA61FA36B>()) {
        rh::native<0x16876A25, void>(owned_actor);
        rh::native<0x5A795F3A>(owned_actor, root);
    }
    owned_actor = -1;
}

bool eligible(int player, int actor) {
    if (!rh::native<0xBA6C3E92>(actor) || !rh::native<0x2F232639>(actor)) return false;
    if (!rh::native<0x9613C2D0>(player)) return false;
    if (rh::native<0x6148423A>(player)) return false;
    if (!rh::native<0x63D6551C>(actor) || rh::native<0xF6BF4242>(actor)) return false;
    if (rh::native<0xD39C4A9E>(actor) || rh::native<0xEBBE1CAC>(actor)) return false;
    if (rh::native<0x39C518DB>(actor) || rh::native<0x4B441DC4>(actor)) return false;
    const int weapon = rh::native<0xA4B2016D>(actor);
    // SDK enum: the first eight weapons are pistols and revolvers.
    return weapon >= 0 && weapon <= 7 && rh::native<0xAB5FB5AC>(actor);
}

void shoot(int actor, ULONGLONG now) {
    const int camera = rh::native<0x6B7677BF>();
    Vec3 position{}, direction{};
    rh::native<0x4A65F0B7, void>(camera, &position);
    rh::native<0xBBD1078A, void>(camera, &direction);
    const float length = std::sqrt(direction.x * direction.x + direction.y * direction.y
                                 + direction.z * direction.z);
    if (!std::isfinite(length) || length < 0.01f) return;
    Vec3 target{position.x + direction.x * (100.0f / length),
                position.y + direction.y * (100.0f / length),
                position.z + direction.z * (100.0f / length)};
    if (!std::isfinite(target.x) || !std::isfinite(target.y) || !std::isfinite(target.z)) return;
    // Preserve 0.2's forced hip node and immediate task. Supply the missing
    // player aiming state through its native, without changing actor transforms.
    if (!rh::native<0x5A795F3A>(actor, pose)) return;
    forced_aim_player = rh::native<0xAD68A22E>();
    rh::native<0x1CFAF2EA, void>(forced_aim_player, 1);
    owned_actor = actor;
    release_at = now + 300;
    rh::native<0x601C22E3, void>(actor, &target, 0.25f);
}

void validate_shot() {
    if (owned_actor == -1) return;
    if (!rh::native<0xBA6C3E92>(owned_actor) || !rh::native<0x2F232639>(owned_actor)
            || owned_actor != rh::native<0xE8CFDD53>(rh::native<0xAD68A22E>())) {
        release();
    }
}

void script() {
    bool previous_left = true, previous_toggle = true;
    ULONGLONG next_shot = 0;
    for (;;) {
        const bool focused = foreground();
        const bool left = focused && down(VK_LBUTTON);
        const bool right = focused && down(VK_RBUTTON);
        const bool toggle = focused && down(VK_F7);
        const bool clicked = focused && left && !previous_left;
        if (toggle && !previous_toggle) enabled = !enabled;
        const ULONGLONG now = GetTickCount64();
        const bool blocked = !focused || !enabled || right || rh::native<0x57246C02>()
                          || rh::native<0xA61FA36B>();
        if (owned_actor != -1 && (blocked || now >= release_at
                || rh::native<0x6148423A>(rh::native<0xAD68A22E>()))) release();
        if (owned_actor != -1 && !blocked) validate_shot();
        if (!blocked && clicked && owned_actor == -1 && now >= next_shot) {
            const int player = rh::native<0xAD68A22E>();
            const int actor = rh::native<0xE8CFDD53>(player);
            if (eligible(player, actor)) {
                shoot(actor, now);
                if (owned_actor != -1) next_shot = now + 350;
            }
        }
        // Suppress clicks caused by returning focus with the mouse already held.
        previous_left = focused ? left : true;
        previous_toggle = focused ? toggle : true;
        rh::wait(0);
    }
}
}

BOOL APIENTRY DllMain(HMODULE module, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(module);
        if (!rh::bind()) return FALSE;
        rh::script_register(module, script);
    } else if (reason == DLL_PROCESS_DETACH && rh::script_unregister) {
        // Native functions must not run under the loader lock. Use F7 in-game
        // to release the task before unloading this experimental plugin.
        rh::script_unregister(module);
    }
    return TRUE;
}
