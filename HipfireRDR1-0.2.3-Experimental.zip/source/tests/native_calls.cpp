#include <algorithm>
#include <cassert>
#include <cstring>
#include <limits>
#include <map>
#include <string>
#include <vector>
#include "../src/hipfire.cpp"

namespace test {
std::uint32_t hash;
std::vector<std::uint64_t> args;
std::vector<std::uint32_t> calls;
std::map<std::uint32_t,int> flags;
std::uint64_t result;
Vec3 direction{0,0,1}, target{};
int shots=0, clears=0, force_on=0, force_off=0;
bool forced=false;
std::string node;
void init(std::uint32_t h) { hash=h; args.clear(); }
void push(std::uint64_t a) { args.push_back(a); }
float number(std::uint64_t a) { float v; std::memcpy(&v,&a,4); return v; }
std::uint64_t* call() {
    calls.push_back(hash); result=static_cast<std::uint32_t>(flags[hash]);
    if (hash==0x4A65F0B7) *reinterpret_cast<Vec3*>(args.at(1))={10,20,30};
    if (hash==0xBBD1078A) *reinterpret_cast<Vec3*>(args.at(1))=direction;
    if (hash==0x5A795F3A) node=reinterpret_cast<const char*>(args.at(1));
    if (hash==0x1CFAF2EA) {
        assert(args.size()==2 && args.at(0)==0);
        forced=args.at(1)!=0;
        if (forced) ++force_on; else ++force_off;
    }
    if (hash==0x601C22E3) {
        assert(args.size()==3 && args.at(0)==42 && number(args.at(2))==0.25f);
        assert(node==pose && forced);
        target=*reinterpret_cast<Vec3*>(args.at(1)); ++shots;
    }
    if (hash==0x16876A25) { assert(!forced && args.at(0)==42); ++clears; }
    return &result;
}
bool called(std::uint32_t h) { return std::find(calls.begin(),calls.end(),h)!=calls.end(); }
void reset() {
    calls.clear(); flags.clear(); owned_actor=-1; forced_aim_player=-1; release_at=0;
    direction={0,0,1}; shots=clears=force_on=force_off=0; forced=false; node.clear();
    enabled=true;
    for (auto h:{0xBA6C3E92u,0x2F232639u,0x9613C2D0u,0x63D6551Cu,0xAB5FB5ACu,0x5A795F3Au}) flags[h]=1;
    flags[0xA4B2016D]=4; flags[0xE8CFDD53]=42;
}
struct Stop {};
struct Frame { ULONGLONG now; int key; bool focus=true; bool pause=false; bool deadeye=false; };
std::vector<Frame> frames;
std::size_t frame;
void apply_frame() {
    auto f=frames.at(frame);
    testwin::ticks=f.now; testwin::focused=f.focus;
    std::fill(std::begin(testwin::keys),std::end(testwin::keys),0);
    testwin::keys[f.key]=static_cast<short>(0x8000);
    flags[0x57246C02]=f.pause; flags[0x6148423A]=f.deadeye;
}
void wait(std::uint64_t) {
    if (++frame==frames.size()) throw Stop{};
    apply_frame();
}
void run(std::vector<Frame> fs) {
    frames=fs; frame=0; apply_frame(); rh::wait=test::wait;
    try { script(); } catch (Stop&) {}
}
}

int main() {
    rh::init=test::init; rh::push=test::push; rh::call=test::call;
    test::reset(); assert(eligible(0,42));
    for (auto h:{0x6148423Au,0xF6BF4242u,0xD39C4A9Eu,0xEBBE1CACu,0x39C518DBu,0x4B441DC4u}) {
        test::reset(); test::flags[h]=1; assert(!eligible(0,42));
    }
    test::reset(); shoot(42,1000);
    assert(test::shots==1 && release_at==1300 && owned_actor==42 && test::force_on==1);
    assert(test::target.x==10 && test::target.y==20 && test::target.z==130);
    for (auto h:{0xECE8520Bu,0x42DE39F0u,0x9C40E671u,0x5AB552C6u,0x195A4286u}) assert(!test::called(h));
    validate_shot(); assert(test::shots==1 && test::forced);
    release(); assert(!test::forced && owned_actor==-1 && test::clears==1 && test::node==root);
    release(); assert(test::force_off==1);
    test::reset(); test::flags[0x5A795F3A]=0; shoot(42,1000);
    assert(test::shots==0 && !test::forced && test::force_on==0);
    test::reset(); test::direction.x=std::numeric_limits<float>::quiet_NaN(); shoot(42,1000);
    assert(test::shots==0 && !test::forced && test::force_on==0);
    for (auto h:{0xBA6C3E92u,0x2F232639u}) {
        test::reset(); shoot(42,1000); test::flags[h]=0; validate_shot();
        assert(owned_actor==-1 && !test::forced && test::force_off==1 && test::clears==0);
    }
    test::reset(); shoot(42,1000); test::flags[0xE8CFDD53]=43; validate_shot();
    assert(owned_actor==-1 && !test::forced && test::clears==0);
    test::reset(); shoot(42,1000); test::flags[0xA61FA36B]=1; release();
    assert(!test::forced && test::clears==0);
    // Exercise the actual input loop, including every way to cancel the flag.
    for (auto end:std::vector<test::Frame>{{1300,0},{1016,VK_RBUTTON},
            {1016,VK_F7},{1016,0,false},{1016,0,true,true},{1016,0,true,false,true}}) {
        test::reset(); test::run({{900,0},{1000,VK_LBUTTON},end});
        assert(test::shots==1 && test::force_on==1 && test::force_off==1);
        assert(!test::forced && owned_actor==-1 && forced_aim_player==-1);
    }
    test::reset(); test::run({{900,0},{1000,VK_LBUTTON},{1016,VK_LBUTTON},{1032,VK_LBUTTON},{1300,0}});
    assert(test::shots==1 && !test::forced); // held LMB cannot restart the task
}
