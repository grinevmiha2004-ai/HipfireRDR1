#pragma once
// Minimal Windows declarations for portable native-call tests only.
#include <cstdint>
#define APIENTRY
using HMODULE = void*;
using HWND = void*;
using LPVOID = void*;
using DWORD = std::uint32_t;
using ULONGLONG = std::uint64_t;
using BOOL = int;
constexpr int FALSE=0, TRUE=1, DLL_PROCESS_ATTACH=1, DLL_PROCESS_DETACH=0;
constexpr int VK_LBUTTON=1, VK_RBUTTON=2, VK_F7=0x76;
inline HMODULE GetModuleHandleW(const wchar_t*) { return nullptr; }
inline void* GetProcAddress(HMODULE, const char*) { return nullptr; }
namespace testwin { inline short keys[256]{}; inline ULONGLONG ticks=0; inline bool focused=true; }
inline HWND GetForegroundWindow() { return nullptr; }
inline DWORD GetCurrentProcessId() { return 1; }
inline DWORD GetWindowThreadProcessId(HWND, DWORD* p) { *p=testwin::focused ? 1 : 2; return 1; }
inline short GetAsyncKeyState(int key) { return testwin::keys[key]; }
inline ULONGLONG GetTickCount64() { return testwin::ticks; }
inline BOOL DisableThreadLibraryCalls(HMODULE) { return TRUE; }
