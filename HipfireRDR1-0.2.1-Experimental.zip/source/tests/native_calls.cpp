#include <cassert>
#include <cstring>
#include <limits>
#include <map>
#include <string>
#include <vector>
#include "../src/hipfire.cpp"

namespace test {
std::uint32_t hash;
std::vector<std::uint64_t> args;
std::vector<std::uint32_t> calls;
std::map<std::uint32_t,int> flags;
std::uint64_t result;
Vec3 direction{0,0,1}, target{};
float heading=37, correction=999;
int shots=0, clears=0, corrections=0;
std::string node;
void init(std::uint32_t h) { hash=h; args.clear(); }
void push(std::uint64_t a) { args.push_back(a); }
float number(std::uint64_t a) { float v; std::memcpy(&v,&a,4); return v; }
std::uint64_t* call() {
    calls.push_back(hash); result=static_cast<std::uint32_t>(flags[hash]);
    if (hash==0x4A65F0B7) *reinterpret_cast<Vec3*>(args.at(1))={10,20,30};
    if (hash==0xBBD1078A) *reinterpret_cast<Vec3*>(args.at(1))=direction;
    if (hash==0x42DE39F0) std::memcpy(&result,&heading,4);
    if (hash==0x5A795F3A) node=reinterpret_cast<const char*>(args.at(1));
    if (hash==0x601C22E3) {
        assert(args.size()==3 && args.at(0)==42 && number(args.at(2))==0.25f);
        assert(node==pose); target=*reinterpret_cast<Vec3*>(args.at(1));
        ++shots;
        heading+=90; // Simulate the reported task-induced turn.
    }
    if (hash==0xECE8520B) {
        assert(args.size()==3 && args.at(0)==42 && args.at(2)==0);
        correction=number(args.at(1)); heading=correction; ++corrections;
    }
    if (hash==0x16876A25) ++clears;
    return &result;
}
bool called(std::uint32_t h) { for (auto x:calls) if (x==h) return true; return false; }
void reset() {
    calls.clear(); flags.clear(); owned_actor=-1; release_at=0;
    direction={0,0,1}; heading=37; correction=999;
    shots=clears=corrections=0; node.clear();
    for (auto h:{0xBA6C3E92u,0x2F232639u,0x9613C2D0u,0x63D6551Cu,0xAB5FB5ACu,0x5A795F3Au}) flags[h]=1;
    flags[0xA4B2016D]=4; flags[0xE8CFDD53]=42;
}
}

int main() {
    rh::init=test::init; rh::push=test::push; rh::call=test::call;
    test::reset(); assert(eligible(0,42));
    for (auto h:{0x6148423Au,0xF6BF4242u,0xD39C4A9Eu,0xEBBE1CACu,0x39C518DBu,0x4B441DC4u}) {
        test::reset(); test::flags[h]=1; assert(!eligible(0,42));
    }
    test::reset(); test::flags[0xA4B2016D]=8; assert(!eligible(0,42));
    for (float facing:{37.0f,-170.0f,0.0f,359.0f}) {
        test::reset(); test::heading=facing; shoot(42,1000);
        // Original 0.2 fires immediately: no preparation phase or animation change.
        assert(test::shots==1 && release_at==1300 && owned_actor==42);
        assert(test::target.x==10 && test::target.y==20 && test::target.z==130);
        retain_facing(); assert(test::heading==facing && test::corrections==1);
        retain_facing(); assert(test::corrections==1 && test::shots==1);
        test::heading=facing-180; retain_facing();
        assert(test::heading==facing && test::corrections==2);
        assert(!test::called(0x9C40E671) && !test::called(0x5AB552C6) && !test::called(0x195A4286));
        release(); assert(owned_actor==-1 && test::clears==1 && test::node==root);
        retain_facing(); assert(test::corrections==2);
    }
    test::reset(); test::heading=359.9f; shoot(42,1000); test::heading=-0.1f;
    retain_facing(); assert(test::corrections==0);
    test::reset(); test::direction={2,0,0}; shoot(42,1000);
    assert(test::target.x==110 && test::target.z==30 && saved_heading==37);
    test::reset(); test::flags[0x5A795F3A]=0; shoot(42,1000);
    assert(owned_actor==-1 && test::shots==0);
    test::reset(); test::direction.x=std::numeric_limits<float>::quiet_NaN(); shoot(42,1000);
    assert(owned_actor==-1 && test::shots==0);
    test::reset(); test::heading=std::numeric_limits<float>::infinity(); shoot(42,1000);
    assert(owned_actor==-1 && test::shots==0);
    test::reset(); shoot(42,1000); test::flags[0xBA6C3E92]=0;
    retain_facing(); assert(owned_actor==-1 && test::corrections==0);
    test::reset(); shoot(42,1000); test::flags[0xA61FA36B]=1;
    release(); assert(owned_actor==-1 && test::clears==0);
}
