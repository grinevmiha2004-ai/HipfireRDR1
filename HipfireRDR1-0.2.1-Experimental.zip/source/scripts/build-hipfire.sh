#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
compiler="${CXX:-x86_64-w64-mingw32-g++}"
mkdir -p build
"$compiler" -std=c++17 -O2 -Wall -Wextra -Werror -Wno-cast-function-type \
  -shared -static-libgcc -static-libstdc++ src/hipfire.cpp \
  -o build/HipfireRDR1.red -luser32 -Wl,--no-insert-timestamp
