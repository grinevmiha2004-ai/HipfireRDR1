@echo off
setlocal
cd /d "%~dp0.."
if not exist build mkdir build
cl /nologo /std:c++17 /EHsc /O2 /W4 /MT /LD src\hipfire.cpp /Fobuild\hipfire.obj /link user32.lib /OUT:build\HipfireRDR1.red
exit /b %errorlevel%
