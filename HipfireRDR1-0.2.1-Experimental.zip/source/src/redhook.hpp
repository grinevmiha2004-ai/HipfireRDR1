#pragma once
#include <windows.h>
#include <cstdint>
#include <cstring>
#include <type_traits>
// RedHook x64 C++ exports. Fail closed if a different ABI is installed.
// See docs/RESEARCH.md for the SDK example and native database revisions.
namespace rh {
using Register = void (*)(HMODULE, void (*)());
using Unregister = void (*)(HMODULE);
using Wait = void (*)(std::uint64_t);
using Init = void (*)(std::uint32_t);
using Push = void (*)(std::uint64_t);
using Call = std::uint64_t* (*)();
Register script_register;
Unregister script_unregister;
Wait wait;
Init init;
Push push;
Call call;

template<class T> bool symbol(HMODULE module, T& out, const char* name) {
    out = reinterpret_cast<T>(GetProcAddress(module, name));
    return out != nullptr;
}

bool bind() {
    HMODULE module = GetModuleHandleW(L"RedHook.dll");
    if (!module) module = GetModuleHandleW(L"RedHook.asi");
    if (!module) return false;
    return symbol(module, script_register, "?ScriptRegister@@YAXPEAUHINSTANCE__@@P6AXXZ@Z")
        && symbol(module, script_unregister, "?ScriptUnregister@@YAXPEAUHINSTANCE__@@@Z")
        && symbol(module, wait, "?ScriptWait@@YAX_K@Z")
        && symbol(module, init, "?NativeInit@@YAXI@Z")
        && symbol(module, push, "?NativePush64@@YAX_K@Z")
        && symbol(module, call, "?NativeCall@@YAPEA_KXZ");
}

template<class T> void argument(T value) {
    static_assert(std::is_trivially_copyable_v<T> && sizeof(T) <= 8);
    std::uint64_t bits = 0;
    std::memcpy(&bits, &value, sizeof(value));
    push(bits);
}

template<std::uint32_t Hash, class Result = int, class... Args> Result native(Args... args) {
    init(Hash);
    (argument(args), ...);
    if constexpr (std::is_void_v<Result>) {
        call();
    } else {
        const auto* result = call();
        Result value{};
        if (result) std::memcpy(&value, result, sizeof(value));
        return value;
    }
}
}

