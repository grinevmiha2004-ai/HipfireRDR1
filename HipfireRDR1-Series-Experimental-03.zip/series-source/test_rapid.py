import sys,importlib.util,struct,unittest
from pathlib import Path
sys.path.insert(0,'/workspace/hipfire-reload/python-deps')
import pefile
from unicorn import UcError
from unicorn.x86_const import *
R=Path(__file__).parent
spec=importlib.util.spec_from_file_location('series1','/workspace/hipfire-series/test_series.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
P=pefile.PE(str(R/'output/HipfireRDR1.red'));s.old.PLUGIN_IMAGE=P.get_memory_mapped_image()
class GuardTests(unittest.TestCase):
 def vm(self,base=0x1cf0c0000):
  v=s.old.VM(base);v.clock=1100
  # Install real predicate bytes from the uploaded EXE, not a replacement model.
  v.u.mem_write(v.game+0xca87f0,s.old.GAME_PE.get_data(0xca87f0,34))
  self.assertEqual(struct.unpack('<Q',s.old.GAME_PE.get_data(0x1d346f0,8))[0],v.game+0xca87f0)
  v.q(v.game+0x1d346f0,v.game+0xca87f0)
  def ptr():
   try:return v.getq(v.u.reg_read(UC_X86_REG_RCX))
   except UcError:return 0
  def byte():
   try:v.u.mem_write(v.u.reg_read(UC_X86_REG_RDX),bytes(v.u.mem_read(v.u.reg_read(UC_X86_REG_RCX),1)));return 1
   except UcError:return 0
  def protect():v.i(v.u.reg_read(UC_X86_REG_R9),2);return 1
  v.callbacks[base+0x19a0]=ptr;v.callbacks[base+0x18a0]=byte
  v.callbacks[0x50000400]=protect;v.callbacks[0x50000500]=lambda:v.clock
  v.q(base+0x362f8,0x50000400);v.q(base+0x362a8,0x50000500)
  v.i(base+0xf7cc,42);v.i(base+0x24080,0);v.b(base+0x2407e,1);v.b(base+0x2407f,0)
  v.f(v.frame+0x828,8);v.q(base+0x24060,2000);v.q(v.frame+0x40,1100)
  return v
 def condition(self,v,character=None):
  ctx=v.heap+0x11000;v.q(ctx+0x30,character or v.character)
  slot=v.getq(v.game+0x1d346f0);sp=v.frame-8;v.q(sp,0x5000f000)
  v.u.reg_write(UC_X86_REG_RSP,sp);v.u.reg_write(UC_X86_REG_RCX,v.heap+0x12000);v.u.reg_write(UC_X86_REG_RDX,ctx)
  v.u.emu_start(slot,0x5000f000,count=10000)
  self.assertEqual(v.u.reg_read(UC_X86_REG_RIP),0x5000f000)
  return v.u.reg_read(UC_X86_REG_RAX)&255
 def test_override_real_predicate_for_local_actor_only(self):
  for base in [0x1cf0c0000,0x180000000,0x7ff800000000]:
   v=self.vm(base);self.assertEqual(self.condition(v),0);before=bytes(v.u.mem_read(v.weapon,0x600))
   v.tick();self.assertEqual(v.getq(v.game+0x1d346f0),base+0x65000);self.assertEqual(self.condition(v),1)
   self.assertEqual(bytes(v.u.mem_read(v.weapon,0x600)),before)
   foreign=v.heap+0x14000;v.q(foreign+0xaa8,v.manager);self.assertEqual(self.condition(v,foreign),0)
 def test_original_positive_result_preserved(self):
  v=self.vm();v.tick();v.b(v.base+0xf960,0);v.b(v.weapon+0x5d8,2);self.assertEqual(self.condition(v),1)
 def test_cancelled_controls_and_heartbeat(self):
  changes=[lambda v:v.b(v.base+0xf960,0),lambda v:v.b(v.base+0xf7c8,0),lambda v:v.i(v.base+0xf7cc,-1),lambda v:v.i(v.base+0x24080,4),lambda v:v.b(v.base+0x2407e,0),lambda v:setattr(v,'clock',1301)]
  for change in changes:
   v=self.vm();v.tick();change(v);self.assertEqual(self.condition(v),0)
 def test_empty_or_expired_hold_clears_guard(self):
  for off,empty in [(0x828,True),(0x40,False)]:
   v=self.vm();v.tick()
   if empty:v.f(v.frame+off,0)
   else:v.q(v.base+0x24060,1100)
   v.tick();self.assertEqual(self.condition(v),0)
 def test_signature_or_existing_hook_not_overwritten(self):
  for kind in ['signature','slot']:
   v=self.vm()
   if kind=='signature':v.u.mem_write(v.game+0xca87f0,b'\x90')
   else:v.q(v.game+0x1d346f0,0x50009900)
   before=v.getq(v.game+0x1d346f0);v.tick();self.assertEqual(v.getq(v.game+0x1d346f0),before);self.assertEqual(v.getq(v.base+0x66008),0)
 def test_standing_interval_restored_after_confirmation(self):
  v=self.vm();v.q(v.frame+0x7f0,900);v.q(v.frame+0x788,1050);v.q(v.frame+0x800,1450);v.tick()
  self.assertEqual(v.getq(v.frame+0x800),1250)
 def test_all_four_poses(self):
  for kind in range(4):
   v=self.vm();v.i(v.base+0x24080,kind);before=bytes(v.u.mem_read(v.weapon,0x600));v.tick()
   self.assertEqual(self.condition(v),1)
   self.assertEqual(bytes(v.u.mem_read(v.weapon,0x600)),before)
   foreign=v.heap+0x14000;v.q(foreign+0xaa8,v.manager);self.assertEqual(self.condition(v,foreign),0)
 def test_mode_changes_within_existing_series(self):
  v=self.vm();v.tick()
  for kind in [1,3,2,0,2,3,1,0]:
   v.i(v.base+0x24080,kind);v.tick();self.assertEqual(self.condition(v),1)
  v.i(v.base+0xf7cc,-1);self.assertEqual(self.condition(v),0)
 def test_only_standing_interval_is_shortened(self):
  for kind in range(4):
   v=self.vm();v.i(v.base+0x24080,kind);v.q(v.frame+0x7f0,900);v.q(v.frame+0x788,1050);v.q(v.frame+0x800,1450);v.tick()
   self.assertEqual(v.getq(v.frame+0x800),1250 if kind==0 else 1450)
 def test_unsupported_pose_kinds_refuse_override(self):
  for kind in [-1,4,255]:
   v=self.vm();v.i(v.base+0x24080,kind);v.tick();self.assertEqual(self.condition(v),0)
 def test_preparing_active_shot_keeps_permission_in_all_poses(self):
  for kind in range(4):
   v=self.vm();v.i(v.base+0x24080,kind);v.b(v.frame+0x770,1);v.q(v.frame+0x7f8,1900);v.tick();self.assertEqual(self.condition(v),1)
 def test_final_pe_and_original_sections(self):
  old=pefile.PE('/workspace/hipfire-series/output/HipfireRDR1.red')
  for a,b in zip(old.sections,P.sections):
   x=bytearray(a.get_data());y=bytearray(b.get_data())
   if a.VirtualAddress==0x1000:
    off=0x39b5-0x1000;y[off:off+4]=x[off:off+4]
   self.assertEqual(x,y,a.Name)
  end=0x1000
  for section in P.sections:
   self.assertEqual(section.VirtualAddress,end);end=(end+max(section.Misc_VirtualSize,section.SizeOfRawData)+4095)//4096*4096
  self.assertEqual(end,P.OPTIONAL_HEADER.SizeOfImage);self.assertTrue(P.verify_checksum());self.assertFalse(P.get_warnings())
  self.assertEqual(len(P.DIRECTORY_ENTRY_IMPORT),len(old.DIRECTORY_ENTRY_IMPORT))
if __name__=='__main__':
 suite=unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromTestCase(c) for c in [s.old.Tests,s.SeriesTests,GuardTests]])
 result=unittest.TextTestRunner(verbosity=2).run(suite);sys.exit(not result.wasSuccessful())
