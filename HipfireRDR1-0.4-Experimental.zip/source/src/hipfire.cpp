#define WIN32_LEAN_AND_MEAN
#include "redhook.hpp"
#include <cmath>

// v0.4: play the actual held-weapon firing clip, not an AI aiming task.
// Recovered native layouts and clip hash evidence: docs/ANIMATIONRES_ANALYSIS.md.
namespace {
constexpr const char* fire_clip = "nor_ptl_stn_hld_mid_fir_for";
struct Vec3 { float x, y, z; };
static_assert(sizeof(Vec3) == 12);
enum class Phase { WaitingForClip, Playing, Fired };
Phase phase = Phase::WaitingForClip;
int owned_actor = -1;
int shot_weapon = -1;
ULONGLONG requested_at = 0, playing_at = 0, next_shot = 0;
float ammo_before = 0.0f;
Vec3 shot_target{};
bool enabled = true;

bool finite(Vec3 v) { return std::isfinite(v.x) && std::isfinite(v.y) && std::isfinite(v.z); }
float distance2(Vec3 a, Vec3 b) {
    const float x=a.x-b.x, y=a.y-b.y, z=a.z-b.z;
    return x*x+y*y+z*z;
}
bool foreground() {
    DWORD pid = 0;
    GetWindowThreadProcessId(GetForegroundWindow(), &pid);
    return pid == GetCurrentProcessId();
}
bool down(int key) { return (GetAsyncKeyState(key) & 0x8000) != 0; }

void release() {
    if (owned_actor == -1) return;
    const int player = rh::native<0xAD68A22E>();
    if (rh::native<0xBA6C3E92>(owned_actor) && rh::native<0x2F232639>(owned_actor)
            && owned_actor == rh::native<0xE8CFDD53>(player)
            && rh::native<0x9613C2D0>(player) && !rh::native<0xA61FA36B>()
            && !rh::native<0x6148423A>(player)) {
        rh::native<0x16876A25, void>(owned_actor); // Clear only our animation task.
    }
    owned_actor = -1;
}

bool eligible(int player, int actor) {
    if (!rh::native<0xBA6C3E92>(actor) || !rh::native<0x2F232639>(actor)) return false;
    if (!rh::native<0x9613C2D0>(player) || rh::native<0x6148423A>(player)) return false;
    if (!rh::native<0x63D6551C>(actor) || rh::native<0xF6BF4242>(actor)) return false;
    if (rh::native<0xD39C4A9E>(actor) || rh::native<0xEBBE1CAC>(actor)) return false;
    if (rh::native<0x39C518DB>(actor) || rh::native<0x4B441DC4>(actor)) return false;
    const int weapon = rh::native<0xA4B2016D>(actor);
    if (weapon < 0 || weapon > 7 || !rh::native<0xAB5FB5AC>(actor)) return false;
    const float ammo = rh::native<0x43DEDFAE, float>(actor, weapon);
    return std::isfinite(ammo) && ammo >= 1.0f;
}

void shoot(int actor, ULONGLONG now) {
    const int camera = rh::native<0x6B7677BF>();
    Vec3 camera_position{}, direction{}, actor_position{};
    rh::native<0x4A65F0B7, void>(camera, &camera_position);
    rh::native<0xBBD1078A, void>(camera, &direction);
    rh::native<0x99BD9D6F, void>(actor, &actor_position);
    const float length = std::sqrt(distance2(direction, {}));
    if (!finite(camera_position) || !finite(actor_position) || !std::isfinite(length) || length < 0.01f) return;
    const Vec3 target{camera_position.x + direction.x*100.0f/length,
                      camera_position.y + direction.y*100.0f/length,
                      camera_position.z + direction.z*100.0f/length};
    if (!finite(target)) return;
    const float dx=target.x-actor_position.x, dz=target.z-actor_position.z;
    if (dx*dx+dz*dz < 0.0001f) return;
    // SET_ACTOR_HEADING constructs forward=(sin(h),0,cos(h)). The previous
    // vector-heading native uses atan2(-x,-z), which produced the 180-degree error.
    const float heading = std::atan2(dx,dz)*57.29577951308232f;
    const int weapon = rh::native<0xA4B2016D>(actor);
    const float ammo = rh::native<0x43DEDFAE, float>(actor, weapon);
    const char* definition = rh::native<0x612066E5, const char*>(actor);
    if (weapon < 0 || weapon > 7 || !std::isfinite(ammo) || ammo < 1 || !definition || !*definition) return;
    rh::native<0xECE8520B, void>(actor, heading, 1); // Once, before playback; no per-frame rotation.
    // Recovered nine-argument layout. Blend in/out, speed=1, mask index=0,
    // two booleans=false, final animation override parameter=-1 (no override).
    rh::native<0x5AB552C6, void>(actor, fire_clip, 0.05f, 0.05f, 1.0f, 0, 0, 0, -1.0f);
    owned_actor=actor; shot_weapon=weapon; ammo_before=ammo; shot_target=target;
    requested_at=now; playing_at=0; phase=Phase::WaitingForClip; next_shot=now+550;
}

void update_shot(ULONGLONG now) {
    if (owned_actor == -1) return;
    const int player=rh::native<0xAD68A22E>();
    if (!rh::native<0xBA6C3E92>(owned_actor) || !rh::native<0x2F232639>(owned_actor)
            || owned_actor!=rh::native<0xE8CFDD53>(player)
            || !rh::native<0x9613C2D0>(player) || rh::native<0x6148423A>(player)
            || rh::native<0xA4B2016D>(owned_actor)!=shot_weapon) {
        release(); return;
    }
    if (now-requested_at>=800) { release(); return; }
    const bool playing=rh::native<0x1ADE21EB>(owned_actor, fire_clip);
    if (phase==Phase::WaitingForClip) {
        if (!playing) {
            if (now-requested_at>=300) release();
            return;
        }
        playing_at=now; phase=Phase::Playing;
    }
    if (!playing) { release(); return; }
    if (phase==Phase::Fired) return;
    const float ammo=rh::native<0x43DEDFAE, float>(owned_actor, shot_weapon);
    // A native animation event may already have fired. Never add a duplicate.
    if (std::isfinite(ammo) && ammo<ammo_before-0.5f) { phase=Phase::Fired; return; }
    // Allow the hip firing pose to blend in before emitting its single shot.
    if (now-playing_at<80) return;
    if (!std::isfinite(ammo) || ammo<1) { release(); return; }
    Vec3 origin{}, actor_position{};
    rh::native<0x99BD9D6F, void>(owned_actor, &actor_position);
    if (!rh::native<0x30516389>(owned_actor, "wrist_r", &origin)
            || !finite(origin) || !finite(actor_position) || distance2(origin,actor_position)>9.0f) {
        release(); return;
    }
    Vec3 delta{shot_target.x-origin.x,shot_target.y-origin.y,shot_target.z-origin.z};
    const float length=std::sqrt(distance2(delta,{}));
    if (!std::isfinite(length) || length<0.01f) { release(); return; }
    // Approximate barrel position from the right wrist; no world-origin fallback.
    origin.x+=delta.x*0.18f/length; origin.y+=delta.y*0.18f/length; origin.z+=delta.z*0.18f/length;
    const char* definition=rh::native<0x612066E5, const char*>(owned_actor);
    if (!definition || !*definition) { release(); return; }
    phase=Phase::Fired; // Before mutation: one native projectile request per click.
    // The SDK incorrectly labels arg2 as int. EXE passes it to a string lookup.
    rh::native<0x195A4286, void>(owned_actor, definition, 1.0f, &origin, &shot_target);
    const float after=rh::native<0x43DEDFAE, float>(owned_actor, shot_weapon);
    if (std::isfinite(after) && after>=ammo-0.5f)
        rh::native<0xCC69DCC1, void>(owned_actor, shot_weapon, -1);
}

void script() {
    bool previous_left=true, previous_toggle=true;
    for (;;) {
        const bool focused=foreground();
        const bool left=focused && down(VK_LBUTTON), right=focused && down(VK_RBUTTON);
        const bool toggle=focused && down(VK_F7);
        const bool clicked=left && !previous_left;
        if (toggle && !previous_toggle) enabled=!enabled;
        const ULONGLONG now=GetTickCount64();
        const bool blocked=!focused || !enabled || right || rh::native<0x57246C02>() || rh::native<0xA61FA36B>();
        if (blocked) release(); else update_shot(now);
        if (!blocked && clicked && owned_actor==-1 && now>=next_shot) {
            const int player=rh::native<0xAD68A22E>();
            const int actor=rh::native<0xE8CFDD53>(player);
            if (eligible(player,actor)) shoot(actor,now);
        }
        previous_left=focused ? left : true; previous_toggle=focused ? toggle : true;
        rh::wait(0);
    }
}
}

BOOL APIENTRY DllMain(HMODULE module, DWORD reason, LPVOID) {
    if (reason==DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(module);
        if (!rh::bind()) return FALSE;
        rh::script_register(module,script);
    } else if (reason==DLL_PROCESS_DETACH && rh::script_unregister) {
        rh::script_unregister(module);
    }
    return TRUE;
}
