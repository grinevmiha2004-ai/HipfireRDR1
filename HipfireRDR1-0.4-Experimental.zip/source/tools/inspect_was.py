"""Inspect the clip dictionary of an already decompressed WAS resource.
Usage: python tools/inspect_was.py ptl_cat.was --alias nor_ptl_stn_hld_mid_fir_for
No game files are modified. Supports the observed RSC05 payload layout only.
"""
import argparse
import hashlib
import json
import math
import struct
from pathlib import Path


def clip_hash(text):
    h = 0
    for c in text.lower().replace('\\', '/').encode('ascii'):
        h = (h+c) & 0xffffffff
        h = (h+(h << 10)) & 0xffffffff
        h ^= h >> 6
    h = (h+(h << 3)) & 0xffffffff
    h ^= h >> 11
    return (h+(h << 15)) & 0xffffffff


def inspect(data, alias=None):
    def read(offset, fmt):
        if offset < 0 or offset+struct.calcsize(fmt)>len(data):
            raise ValueError(f'Read outside resource: {offset:#x}')
        return struct.unpack_from(fmt, data, offset)
    def pointer(p):
        if p >> 28 != 5:
            raise ValueError(f'Unexpected pointer: {p:#x}')
        return p & 0x0fffffff
    def string(offset):
        end=data.find(b'\0', offset, offset+512)
        if end<0: raise ValueError('Missing string terminator')
        return data[offset:end].decode('ascii')
    buckets, capacity, count=read(8, '<IHH')
    if count>capacity: raise ValueError('Invalid dictionary count')
    seen=set(); result=[]
    for p in read(pointer(buckets), f'<{capacity}I'):
        at=pointer(p) if p else None
        while at is not None:
            if at in seen: raise ValueError('Repeated dictionary node')
            seen.add(at)
            key, obj, nxt=read(at, '<III'); obj=pointer(obj)
            clip=string(pointer(read(obj+8,'<I')[0]))
            item={'key':hex(key), 'object_offset':hex(obj), 'clip':clip}
            if alias is not None and key==clip_hash(alias): item['matched_alias']=alias
            if read(obj,'<I')[0]==0x04a6d218:
                start,end,rate=read(obj+0x2c,'<3f')
                if all(math.isfinite(f) for f in (start,end,rate)):
                    item.update(start=start,end=end,rate=rate)
            result.append(item)
            at=pointer(nxt) if nxt else None
    if len(seen)!=count: raise ValueError('Dictionary count does not match traversal')
    return {'sha256':hashlib.sha256(data).hexdigest(),'clips':result}


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('was',type=Path); parser.add_argument('--alias')
    args=parser.parse_args()
    print(json.dumps(inspect(args.was.read_bytes(),args.alias),indent=2))
