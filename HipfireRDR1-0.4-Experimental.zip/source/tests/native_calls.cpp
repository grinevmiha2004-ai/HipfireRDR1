#include <cassert>
#include <cstring>
#include <limits>
#include <map>
#include <string>
#include <vector>
#include "../src/hipfire.cpp"

namespace test {
std::uint32_t hash;
std::vector<std::uint64_t> args;
std::vector<std::uint32_t> calls;
std::map<std::uint32_t,int> flags;
std::uint64_t result;
Vec3 direction{0,0,1}, target{}, origin{};
float ammo=6, heading=999;
bool playing=false, bone_ok=true, engine_debits=false;
int projectiles=0, charges=0;
constexpr const char definition[]="pistol_cattleman";
void init(std::uint32_t h) { hash=h; args.clear(); }
void push(std::uint64_t a) { args.push_back(a); }
float number(std::uint64_t a) { float v; std::memcpy(&v,&a,4); return v; }
std::uint64_t* call() {
    calls.push_back(hash); result=static_cast<std::uint32_t>(flags[hash]);
    if (hash==0x99BD9D6F || hash==0x4A65F0B7) *reinterpret_cast<Vec3*>(args.at(1))={10,20,30};
    if (hash==0xBBD1078A) *reinterpret_cast<Vec3*>(args.at(1))=direction;
    if (hash==0x43DEDFAE) std::memcpy(&result,&ammo,4);
    if (hash==0x612066E5) result=reinterpret_cast<std::uint64_t>(definition);
    if (hash==0xECE8520B) heading=number(args.at(1));
    if (hash==0x5AB552C6) {
        assert(args.size()==9 && args.at(0)==42);
        assert(std::string(reinterpret_cast<const char*>(args.at(1)))==fire_clip);
        assert(number(args.at(4))==1 && args.at(5)==0 && args.at(6)==0 && args.at(7)==0);
        assert(number(args.at(8))==-1);
    }
    if (hash==0x1ADE21EB) result=playing;
    if (hash==0x30516389) {
        assert(std::string(reinterpret_cast<const char*>(args.at(1)))=="wrist_r");
        *reinterpret_cast<Vec3*>(args.at(2))={10.2f,21.0f,30.1f}; result=bone_ok;
    }
    if (hash==0x195A4286) {
        assert(args.size()==5 && args.at(0)==42 && number(args.at(2))==1);
        assert(std::string(reinterpret_cast<const char*>(args.at(1)))==definition);
        origin=*reinterpret_cast<Vec3*>(args.at(3)); target=*reinterpret_cast<Vec3*>(args.at(4));
        ++projectiles; if (engine_debits) ammo-=1;
    }
    if (hash==0xCC69DCC1) {
        assert(args.at(0)==42 && args.at(1)==4 && static_cast<int>(args.at(2))==-1);
        ++charges; ammo-=1;
    }
    return &result;
}
bool called(std::uint32_t h) { for (auto x:calls) if (x==h) return true; return false; }
void reset() {
    calls.clear(); flags.clear(); owned_actor=-1; next_shot=0;
    direction={0,0,1}; ammo=6; heading=999; playing=false; bone_ok=true;
    engine_debits=false; projectiles=charges=0;
    for (auto h:{0xBA6C3E92u,0x2F232639u,0x9613C2D0u,0x63D6551Cu,0xAB5FB5ACu}) flags[h]=1;
    flags[0xA4B2016D]=4; flags[0xE8CFDD53]=42;
}
void ready() { shoot(42,1000); playing=true; update_shot(1016); }
}

int main() {
    rh::init=test::init; rh::push=test::push; rh::call=test::call;
    test::reset(); assert(eligible(0,42));
    for (auto h:{0x6148423Au,0xF6BF4242u,0xD39C4A9Eu,0xEBBE1CACu,0x39C518DBu,0x4B441DC4u}) {
        test::reset(); test::flags[h]=1; assert(!eligible(0,42));
    }
    test::reset(); test::ammo=0; assert(!eligible(0,42));
    test::reset(); test::flags[0xA4B2016D]=8; assert(!eligible(0,42));
    test::reset(); shoot(42,1000);
    assert(test::heading==0 && test::projectiles==0 && test::called(0x5AB552C6));
    assert(!test::called(0x601C22E3) && !test::called(0x5A795F3A));
    update_shot(1299); assert(owned_actor==42 && test::projectiles==0);
    update_shot(1300); assert(owned_actor==-1 && test::projectiles==0 && test::charges==0);
    test::reset(); test::ready(); update_shot(1095); assert(test::projectiles==0);
    update_shot(1096); assert(test::projectiles==1 && test::charges==1 && test::ammo==5);
    assert(test::target.x==10 && test::target.z==130 && test::origin.z>30.1f);
    update_shot(1120); update_shot(1160); assert(test::projectiles==1 && test::charges==1);
    test::reset(); test::engine_debits=true; test::ready(); update_shot(1096);
    assert(test::projectiles==1 && test::charges==0 && test::ammo==5);
    test::reset(); test::ready(); test::ammo=5; update_shot(1030); update_shot(1096);
    assert(test::projectiles==0 && test::charges==0 && phase==Phase::Fired);
    test::reset(); test::ready(); test::bone_ok=false; update_shot(1096);
    assert(test::projectiles==0 && test::charges==0 && owned_actor==-1);
    test::reset(); test::ready(); test::playing=false; update_shot(1096);
    assert(test::projectiles==0 && test::charges==0 && owned_actor==-1);
    test::reset(); test::direction.x=std::numeric_limits<float>::quiet_NaN(); shoot(42,1000);
    assert(owned_actor==-1 && !test::called(0x5AB552C6));
    test::reset(); test::ready(); test::flags[0xA4B2016D]=5; update_shot(1096);
    assert(test::projectiles==0 && test::charges==0 && owned_actor==-1);
    test::reset(); test::ready(); release(); update_shot(1096); assert(test::projectiles==0);
    test::reset(); test::direction={1,0,0}; shoot(42,1000); assert(std::fabs(test::heading-90)<0.001f);
    test::reset(); test::direction={0,0,-1}; shoot(42,1000); assert(std::fabs(std::fabs(test::heading)-180)<0.001f);
}
