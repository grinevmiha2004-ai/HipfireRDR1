import sys,struct,subprocess,hashlib
from pathlib import Path
sys.path.insert(0,'/workspace/hipfire-reload/python-deps')
import pefile
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
r=Path(__file__).parent
for cmd in [ ['g++','-std=c++17','-O2','-Wall','-Wextra','-Werror','-fpie','-ffreestanding','-fno-exceptions','-fno-rtti','-fno-stack-protector','-fasynchronous-unwind-tables','-mabi=ms','-mno-red-zone','-maccumulate-outgoing-args','-c','rapid.cpp','-o','rapid.o'],['as','--64','bridge.S','-o','bridge.o'],['ld','-T','rapid.ld','rapid.o','bridge.o','-o','rapid.elf']]:subprocess.run(cmd,cwd=r,check=True)
for section,name in [('.text','code'),('.data','data')]:subprocess.run(['objcopy','-O','binary','--only-section='+section,'rapid.elf',name+'.bin'],cwd=r,check=True)
syms={l.split()[3]:(int(l.split()[0],16),int(l.split()[1],16)) for l in subprocess.check_output(['nm','-S','--defined-only','rapid.elf'],cwd=r,text=True).splitlines() if len(l.split())==4}
src=Path('/workspace/hipfire-series/output/HipfireRDR1.red').read_bytes();assert hashlib.sha256(src).hexdigest()=='97d542a2b9643a2ddd171d475318f33f1e119ea021d56ed7c9b9d9e4cc6230de'
p=pefile.PE(data=src);b=bytearray(src);code=bytearray((r/'code.bin').read_bytes())
parent=next(e.struct for e in p.DIRECTORY_ENTRY_EXCEPTION if e.struct.BeginAddress<=0x39b4<e.struct.EndAddress)
entries=[];regs={'rbx':3,'rbp':5,'rsi':6,'rdi':7,'r12':12,'r13':13,'r14':14,'r15':15}
md=Cs(CS_ARCH_X86,CS_MODE_64)
for name in ['rapid_condition','rapid_update','rapid_bridge']:
 start,size=syms[name];ops=[];prolog=0
 for i in md.disasm(bytes(code[start-0x65000:start-0x65000+100]),start):
  off=i.address+i.size-start
  if i.mnemonic=='pushfq' or (i.mnemonic=='push' and i.op_str not in regs):ops.append(bytes([off,2]))
  elif i.mnemonic=='push':ops.append(bytes([off,regs[i.op_str]<<4]))
  elif i.mnemonic=='mov':continue
  elif i.mnemonic=='sub' and i.op_str.startswith('rsp, '):
   n=int(i.op_str.split(', ')[1],0);ops.append(bytes([off,((n//8-1)<<4)|2]) if n<=128 else bytes([off,1])+struct.pack('<H',n//8));prolog=off;break
  else:raise AssertionError((name,i.mnemonic,i.op_str))
 assert prolog
 while len(code)%4:code.append(0)
 unwind=0x65000+len(code);blob=b''.join(reversed(ops));count=len(blob)//2;bridge=name.endswith('bridge')
 code+=bytes([0x21 if bridge else 1,prolog,count,0])+blob
 if count%2:code+=b'\0\0'
 if bridge:code+=struct.pack('<III',parent.BeginAddress,parent.EndAddress,parent.UnwindData)
 entries.append((start,start+size,unwind))
while len(code)%4:code.append(0)
table=0x65000+len(code)
entries=sorted([(e.struct.BeginAddress,e.struct.EndAddress,e.struct.UnwindData) for e in p.DIRECTORY_ENTRY_EXCEPTION]+entries)
code+=b''.join(struct.pack('<III',*e) for e in entries);assert len(code)<=0x1000
old=p.get_offset_from_rva(0x39b4);assert b[old]==0xe9 and struct.unpack_from('<i',b,old+1)[0]+0x39b4+5==0x62643
b[old+1:old+5]=struct.pack('<i',syms['rapid_bridge'][0]-0x39b4-5)
align=lambda n,a:(n+a-1)//a*a
for name,rva,data,flags in [(b'.rpdguard',0x65000,code,0x60000020),(b'.rpddata',0x66000,(r/'data.bin').read_bytes(),0xc0000040)]:
 raw=align(len(b),512);size=align(len(data),512);b+=b'\0'*(raw-len(b))+data+b'\0'*(size-len(data))
 h=p.sections[0].get_file_offset()+p.FILE_HEADER.NumberOfSections*40;assert h+40<=p.OPTIONAL_HEADER.SizeOfHeaders and not any(b[h:h+40])
 b[h:h+40]=struct.pack('<8sIIIIIIHHI',name,len(data),rva,size,raw,0,0,0,0,flags);p.FILE_HEADER.NumberOfSections+=1
 field='SizeOfCode' if flags&0x20 else 'SizeOfInitializedData';struct.pack_into('<I',b,p.OPTIONAL_HEADER.get_field_absolute_offset(field),getattr(p.OPTIONAL_HEADER,field)+size)
struct.pack_into('<H',b,p.FILE_HEADER.get_field_absolute_offset('NumberOfSections'),p.FILE_HEADER.NumberOfSections)
struct.pack_into('<I',b,p.OPTIONAL_HEADER.get_field_absolute_offset('SizeOfImage'),0x67000)
struct.pack_into('<II',b,p.OPTIONAL_HEADER.DATA_DIRECTORY[3].get_file_offset(),table,len(entries)*12)
q=pefile.PE(data=b);struct.pack_into('<I',b,p.OPTIONAL_HEADER.get_field_absolute_offset('CheckSum'),q.generate_checksum())
(r/'output').mkdir(exist_ok=True);(r/'output/HipfireRDR1.red').write_bytes(b)
print('Series 02 SHA256',hashlib.sha256(b).hexdigest())
