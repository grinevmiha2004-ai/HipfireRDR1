from pathlib import Path
import sys,subprocess,struct,hashlib
sys.path.insert(0,'/workspace/hipfire-reload/python-deps')
import pefile
R=Path(__file__).parent
SRC=Path('/workspace/hipfire-reload/output/HipfireRDR1.red')
assert hashlib.sha256(SRC.read_bytes()).hexdigest()=='f505c62029c505fd612ef5a686e35206bc7e426d604bd887f975ea0191284152'
for cmd in [['as','--64','standing.S','-o','standing.o'],['ld','-T','series.ld','standing.o','-o','series.elf'],['objcopy','-O','binary','--only-section=.text','series.elf','series.bin']]:subprocess.run(cmd,cwd=R,check=True)
b=bytearray(SRC.read_bytes());p=pefile.PE(data=b)
# Only change standing start branch; existing moving/crouch paths fall through.
o=p.get_offset_from_rva(0x5cad);assert b[o:o+6]==bytes.fromhex('0f84f6000000')
b[o:o+6]=b'\x0f\x84'+struct.pack('<i',0x64000-0x5cad-6)
# Confirmed goal-based shot: retain pose up to 750ms, instead of 350ms.
# Existing next-shot limits, request deadlines and all cancellation checks stay.
o=p.get_offset_from_rva(0x4dda);assert b[o:o+7]==bytes.fromhex('4881c25e010000')
b[o+3:o+7]=struct.pack('<I',750)
code=bytearray((R/'series.bin').read_bytes());function_end=0x64000+len(code)
while len(code)%4:code.append(0)
unwind=0x64000+len(code)
parent=next(e.struct for e in p.DIRECTORY_ENTRY_EXCEPTION if e.struct.BeginAddress<=0x5cad<e.struct.EndAddress)
code+=bytes([0x21,0,0,0])+struct.pack('<III',parent.BeginAddress,parent.EndAddress,parent.UnwindData)
table=0x64000+len(code)
entries=[(e.struct.BeginAddress,e.struct.EndAddress,e.struct.UnwindData) for e in p.DIRECTORY_ENTRY_EXCEPTION]+[(0x64000,function_end,unwind)]
code+=b''.join(struct.pack('<III',*e) for e in sorted(entries))
assert len(code)<=0x1000
align=lambda n,a:(n+a-1)//a*a
raw=align(len(b),p.OPTIONAL_HEADER.FileAlignment);size=align(len(code),p.OPTIONAL_HEADER.FileAlignment)
b+=b'\0'*(raw-len(b))+code+b'\0'*(size-len(code))
h=p.sections[0].get_file_offset()+len(p.sections)*40
assert h+40<=p.OPTIONAL_HEADER.SizeOfHeaders and not any(b[h:h+40])
b[h:h+40]=struct.pack('<8sIIIIIIHHI',b'.series',len(code),0x64000,size,raw,0,0,0,0,0x60000020)
struct.pack_into('<H',b,p.FILE_HEADER.get_field_absolute_offset('NumberOfSections'),len(p.sections)+1)
struct.pack_into('<I',b,p.OPTIONAL_HEADER.get_field_absolute_offset('SizeOfImage'),0x65000)
struct.pack_into('<I',b,p.OPTIONAL_HEADER.get_field_absolute_offset('SizeOfCode'),p.OPTIONAL_HEADER.SizeOfCode+size)
struct.pack_into('<II',b,p.OPTIONAL_HEADER.DATA_DIRECTORY[3].get_file_offset(),table,len(entries)*12)
q=pefile.PE(data=b);struct.pack_into('<I',b,p.OPTIONAL_HEADER.get_field_absolute_offset('CheckSum'),q.generate_checksum())
(R/'output').mkdir(exist_ok=True);(R/'output/HipfireRDR1.red').write_bytes(b)
print('Experimental series SHA256',hashlib.sha256(b).hexdigest())
