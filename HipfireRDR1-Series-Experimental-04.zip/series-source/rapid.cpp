using Q=unsigned long long;using U=unsigned;using B=unsigned char;
#define MS __attribute__((ms_abi))
extern "C" {
extern Q game_image,iat_protect,iat_time,release_at;
extern B input_enabled,mod_enabled,owned_expanded;
extern int owned_actor,owned_kind;
Q MS read_pointer(Q);Q MS actor_from(Q,U);
bool MS read_byte(Q,B*);
void MS log_event(const char*,...);
}
using Condition=bool(MS*)(void*,void*);
using Protect=int(MS*)(void*,Q,U,U*);
using Time=Q(MS*)();
struct Guard {Q original=0,character=0,until=0;U hits=0,reported=0;Q next_log=0;B failed=0;};
Guard guard;
template<class T> T& at(B* f,U o){return *reinterpret_cast<T*>(f+o);}
extern "C" bool MS rapid_condition(void* self,void* context){
 // Preserve every original positive result, including genuine Dead Eye/NPCs.
 const auto original=reinterpret_cast<Condition>(guard.original);
 if(original(self,context))return true;
 Q character=__atomic_load_n(&guard.character,__ATOMIC_ACQUIRE);
 if(!character || !mod_enabled || !input_enabled || !owned_expanded || static_cast<U>(owned_kind)>3 || owned_actor<0)return false;
 if(reinterpret_cast<Time>(iat_time)()>__atomic_load_n(&guard.until,__ATOMIC_ACQUIRE))return false;
 if(read_pointer(reinterpret_cast<Q>(context)+0x30)!=character)return false;
 __atomic_fetch_add(&guard.hits,1U,__ATOMIC_RELAXED);
 return true;
}
struct Seen {U id=0;Q born=0;};
struct Responsive {Seen seen[64];B live=0;};
Responsive responsive __attribute__((section(".responsive")));
extern "C" __attribute__((noinline)) void MS responsive_queue(B* f,bool prune){
 const U kind=static_cast<U>(owned_kind);
 if(!mod_enabled || !input_enabled || !owned_expanded || kind<1 || kind>3
    || owned_actor<0 || at<int>(f,0x768)!=owned_actor){responsive.live=0;return;}
 Q& count=at<Q>(f,0x760);const Q head=at<Q>(f,0x758),now=at<Q>(f,0x40);
 if(count>64 || head>=64)return;
 if(!responsive.live){for(U i=0;i<64;++i)responsive.seen[i].id=0;responsive.live=1;}
 struct Plan {Q a,b,c;};static_assert(sizeof(Plan)==24);
 U kept=0;const U initial=static_cast<U>(count);
 for(U i=0;i<initial;++i){
  const U slot=static_cast<U>((head+i)&63);B* raw=f+0x158+slot*24;
  const U id=*reinterpret_cast<U*>(raw+16);
  Seen& seen=responsive.seen[id&63];
  if(seen.id!=id){seen.id=id;seen.born=now;}
  const bool active=i==0 && at<B>(f,0x770);
  // Expire intent, never an already-started or engine-accepted attempt.
  if(prune && !active && now-seen.born>400){
   log_event("responsive_expired id=%u age_ms=%llu kind=%u",id,now-seen.born,kind);continue;
  }
  if(kept!=i)*reinterpret_cast<Plan*>(f+0x158+((head+kept)&63)*24)=*reinterpret_cast<Plan*>(raw);
  ++kept;
 }
 count=kept;
}
extern "C" void MS rapid_update(B* f){
 responsive_queue(f,false);
 const Q now=at<Q>(f,0x40);const int actor=at<int>(f,0x768);
 const U hits=__atomic_load_n(&guard.hits,__ATOMIC_RELAXED);
 if(hits!=guard.reported && now>=guard.next_log){
  guard.reported=hits;guard.next_log=now+250;log_event("rapid_guard overrides=%u",hits);
 }
 const float ammo=at<float>(f,0x828);
 if(!mod_enabled || !input_enabled || actor<0 || actor!=owned_actor || static_cast<U>(owned_kind)>3 || !owned_expanded
    || !(ammo>0.5f) || (at<B>(f,0x770)?now>=at<Q>(f,0x7f8):now>=release_at)){
  __atomic_store_n(&guard.character,0ULL,__ATOMIC_RELEASE);return;
 }
 const Q image=game_image;
 if(guard.failed)return;
 if(!guard.original){
  const B expected[]={0x48,0x8b,0x42,0x30,0x48,0x85,0xc0,0x74,0x17,0x48,0x8b,0x80,0xa8,0x0a,0,0,0x48,0x8b,0x48,0x08,0x0f,0xb6,0x81,0xd8,5,0,0,0xd0,0xe8,0x24,1,0xc3};
  B v=0;
  for(U i=0;i<sizeof expected;++i)if(!read_byte(image+0xca87f0+i,&v)||v!=expected[i]){
   guard.failed=1;log_event("rapid_guard refused: predicate signature mismatch");return;
  }
  auto* slot=reinterpret_cast<Q*>(image+0x1d346f0);
  const Q target=image+0xca87f0;
  if(read_pointer(reinterpret_cast<Q>(slot))!=target){guard.failed=1;log_event("rapid_guard refused: predicate slot changed");return;}
  U previous=0,ignored=0;
  if(!reinterpret_cast<Protect>(iat_protect)(slot,8,4,&previous)){guard.failed=1;return;}
  guard.original=target;Q compare=target;
  const bool ok=__atomic_compare_exchange_n(slot,&compare,reinterpret_cast<Q>(&rapid_condition),false,__ATOMIC_SEQ_CST,__ATOMIC_SEQ_CST);
  reinterpret_cast<Protect>(iat_protect)(slot,8,previous,&ignored);
  if(!ok){guard.failed=1;guard.original=0;log_event("rapid_guard refused: predicate install conflict");return;}
  log_event("rapid_guard ready: local hipfire series in four poses; no Dead Eye state writes");
 }
 const Q owner=actor_from(image,static_cast<U>(actor));
 const Q character=owner?read_pointer(owner+0x38):0;
 if(!character){__atomic_store_n(&guard.character,0ULL,__ATOMIC_RELEASE);return;}
 __atomic_store_n(&guard.until,now+200ULL,__ATOMIC_RELEASE);
 __atomic_store_n(&guard.character,character,__ATOMIC_RELEASE);
 // Use the proven standing minimum in all four poses. Fresh requests
 // still need two released input frames and the original weapon checks.
 if(!at<B>(f,0x770) && at<Q>(f,0x788) && now-at<Q>(f,0x788)<=750){
  Q next=at<Q>(f,0x7f0)+350,settle=at<Q>(f,0x788)+100;
  if(next<settle)next=settle;
  if(at<Q>(f,0x800)>next)at<Q>(f,0x800)=next;
 }
}
